package com.example.login10.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF000000)
val PurpleGrey80 = Color(0xFFffe42c)
val Pink80 = Color(0xFF1FB8C8)

val Purple40 = Color(0xFF3650a4)
val PurpleGrey40 = Color(0xFF125b71)
val Pink40 = Color(0xFF3D5260)
val Neon20=Color(0xFFacedff)
val Yellow10=Color(0xFFffe42c)